package br.unidep.ads.model;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity 
public class Carrinho extends BaseEntityImpl {

	@ManyToOne
	@JoinColumn(name = "idcliente", referencedColumnName = "id")
	private Cliente cliente;
	@ManyToOne
	@JoinColumn(name = "idproduto", referencedColumnName = "id")
	private Produto produto;
	private Double quantidade;
	private Double preco;
	
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public Produto getProduto() {
		return produto;
	}
	public void setProduto(Produto produto) {
		this.produto = produto;
	}
	public Double getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(Double quantidade) {
		this.quantidade = quantidade;
	}
	public Double getPreco() {
		return preco;
	}
	public void setPreco(Double preco) {
		this.preco = preco;
	}
	
	
	
}
