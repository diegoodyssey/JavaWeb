package br.unidep.ads.exceptions;

/**
 * Classe de exceção que pode ser personalizada
 * @author anderson
 *
 */
public class RegraException extends Exception {

}
