package br.unidep.ads.bean;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.Query;

import br.unidep.ads.model.Cliente;

@LocalBean
@Stateless
public class ClienteBean extends AbstractBeanImpl<Cliente>{

	@Override
	public Class<Cliente> getClasse() {
		return Cliente.class;
	}
	
	@Override
	public List<Cliente> buscarTodos() throws Exception {
		String sql = "Select c From Cliente c ";
		Query query = entity.createQuery(sql);
		return query.getResultList();
	}
	
	public List<Cliente> buscarPorNome(String nome) throws Exception {
		String sql = "Select c From Cliente c where upper(c.nome) like :nome ";
		Query query = entity.createQuery(sql);
		query.setParameter("nome", "%"+nome.toUpperCase().trim()+"%");
		return query.getResultList();
	}
	
	public Boolean existeCPF(String cpf)throws Exception{
		String sql = "Select c From Cliente c where c.cpf = :cpf ";
		Query query = entity.createQuery(sql);
		query.setParameter("cpf", cpf.trim());
		return !query.getResultList().isEmpty();
	}
	
}
