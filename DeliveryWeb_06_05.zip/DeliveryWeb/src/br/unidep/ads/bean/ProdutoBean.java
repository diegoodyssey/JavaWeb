package br.unidep.ads.bean;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.Query;

import br.unidep.ads.model.Produto;

@LocalBean
@Stateless
public class ProdutoBean extends AbstractBeanImpl<Produto>{

	@Override
	public Class<Produto> getClasse() {
		return Produto.class;
	}
	
	@Override
	public List<Produto> buscarTodos() throws Exception {
		String sql = "Select p From Produto p ";
		Query query = entity.createQuery(sql);
		return query.getResultList();
	}
	
	public List<Produto> buscarPorNome(String nome) throws Exception {
		//SQL utilizando JPQL
		//O que é JPQL? -> É uma consulta baseada nas classes do projeto que representa
		//as tabelas do banco
		String sql = "Select p From Produto p where upper(p.nome) like :nome ";
		Query query = entity.createQuery(sql);
		query.setParameter("nome", "%"+nome.toUpperCase()+"%");
		return query.getResultList();
	}
	
	public List<Produto> buscarPorMarca(String marca)throws Exception {
		String sql = "Select p From Produto p where upper(p.marca) like :marca ";
		Query query = entity.createQuery(sql);
		query.setParameter("marca", "%"+marca.toUpperCase().trim()+"%");
		return query.getResultList(); 
	}
	
	public List<Produto> buscarPorCategoria(String categoria)throws Exception {
		/**
		 * Select p.* from produto p inner join categoria c on c.id = p.idcategoria
		 * where upper(c.nome) like ?
		 */
		String sql = "Select p From Produto p where upper(p.categoria.nome)"
				+ " like :categoria ";
		Query query = entity.createQuery(sql);
		query.setParameter("categoria", "%" + categoria.toUpperCase().trim() +"%");
		return query.getResultList();
	}
}