package br.unidep.ads.bean;

import br.unidep.ads.model.BaseEntity;

public interface AbstractBean<T extends BaseEntity> {

	public T salvar(T obj)throws Exception;
	
	public T inserir(T obj)throws Exception;
	
	public T alterar(T obj)throws Exception;
	
	public Boolean deletar(T obj) throws Exception;
	
	public Boolean deletar(Long id) throws Exception;
}
