package br.unidep.ads.bean;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import br.unidep.ads.model.BaseEntity;

public abstract class AbstractBeanImpl<T extends BaseEntity> implements AbstractBean<T>{

	@PersistenceContext(unitName = "DeliveryWeb")
	protected EntityManager entity;
	
	@Override
	public T inserir(T obj) throws Exception {
		entity.persist(obj);
		entity.flush();
		return obj;
	}	
	@Override
	public T alterar(T obj) throws Exception {
		T old = entity.find(getClasse(), obj.getId());
		obj = entity.merge(obj);
		entity.flush();
		return obj;
	}	
	@Override
	public T salvar(T obj) throws Exception {
		if ( obj.getId() == null) {
			return inserir(obj);
		}else {
			return alterar(obj);
		}
	}	
	
	public abstract Class<T> getClasse();
	
	@Override
	public Boolean deletar(T obj) throws Exception {
		T old = entity.find(getClasse(), obj.getId());
		entity.remove(old);
		entity.flush();
		return true;
	} 
	
	@Override
	public Boolean deletar(Long id) throws Exception {
		T old = entity.find(getClasse(), id);
		entity.remove(old);
		entity.flush();
		return true;
	} 
	
	public T getPorCodigo(Long id)throws Exception {
		T obj = entity.find(getClasse(), id);
		return obj;
	}
	
	public abstract List<T> buscarTodos() throws Exception;
}
