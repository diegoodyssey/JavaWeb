package br.unidep.ads.bean;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.Query;

import br.unidep.ads.model.Categoria;

@LocalBean
@Stateless
public class CategoriaBean extends AbstractBeanImpl<Categoria>{

	@Override
	public Class<Categoria> getClasse() {
		return Categoria.class;
	}
	
	@Override
	public List<Categoria> buscarTodos() throws Exception {
		String sql = "Select c From Categoria c ";
		Query query = entity.createQuery(sql);
		return query.getResultList();
	}
	/**
	 * Método que retorna as categorias filtrando pelo nome
	 * @param nome
	 * @return
	 * @throws Exception
	 */
	public List<Categoria> getPorNome(String nome)throws Exception {
		//Consulta no Formato JPQL ->Com base na classe
		String sql = "Select c From Categoria c where upper(c.nome) like :nome ";
		//criando a query a ser executada no banco
		Query query = entity.createQuery(sql);
		//passando parametro para a query utilizar na consulta
		query.setParameter("nome", "%"+nome.toUpperCase().trim()+"%");
		//retornando os dados filtrados pela query
		return query.getResultList();
	}
}
