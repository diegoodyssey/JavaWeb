package br.unidep.ads.bean;

import javax.ejb.Stateless;
import javax.persistence.Query;

import br.unidep.ads.model.Carrinho;

import java.util.List;

import javax.ejb.LocalBean;

@LocalBean
@Stateless
public class CarrinhoBean extends AbstractBeanImpl<Carrinho>{

	@Override
	public Class<Carrinho> getClasse() {
		return Carrinho.class;
	}
	
	@Override
	public List<Carrinho> buscarTodos() throws Exception {
		String sql = "Select c From Carrinho c ";
		Query query = entity.createQuery(sql);
		return query.getResultList();
	}
	
	public List<Carrinho> buscarPorIdCliente(Long idCliente)throws Exception{
		String sql = "Select c From Carrinho c where c.cliente.id = :idCliente ";
		Query query = entity.createQuery(sql);
		query.setParameter("idCliente", idCliente);
		return query.getResultList();
	}
}
