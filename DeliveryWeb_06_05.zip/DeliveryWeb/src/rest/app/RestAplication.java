package rest.app;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import rest.CategoriaWs;
import rest.ProdutoWs;

//localhost:8080/DeliveryWeb/rest
@ApplicationPath("rest")
public class RestAplication extends Application{

	@Override
	public Set<Class<?>> getClasses() {
		Set<Class<?>> sets = new HashSet<Class<?>>();
		sets.add(CategoriaWs.class);
		sets.add(ProdutoWs.class);
		return sets;
	}
	
}
