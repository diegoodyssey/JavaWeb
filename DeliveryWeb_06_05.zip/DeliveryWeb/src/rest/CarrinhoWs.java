package rest;

import javax.ejb.EJB;
import javax.ws.rs.Path;

import br.unidep.ads.bean.AbstractBeanImpl;
import br.unidep.ads.bean.CarrinhoBean;
import br.unidep.ads.model.Carrinho;

@Path("carrinho")
public class CarrinhoWs extends AbsctractWs<Carrinho>{

	@EJB
	private CarrinhoBean carrinhoBean;
	
	@Override
	public AbstractBeanImpl<Carrinho> getBean() {
		return carrinhoBean;
	}
}
