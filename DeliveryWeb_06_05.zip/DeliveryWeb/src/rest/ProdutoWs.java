package rest;

import java.util.List;

import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import br.unidep.ads.bean.ProdutoBean;
import br.unidep.ads.exceptions.RegraException;
import br.unidep.ads.model.Categoria;
import br.unidep.ads.model.Produto;

@Path("produto")
public class ProdutoWs {

	@EJB
	private ProdutoBean produtoBean;
	
	@POST
	@Produces(MediaType.APPLICATION_JSON) //é para definir o tipo de dado que vai retornar
	@Consumes(MediaType.APPLICATION_JSON)//é para definir o tipo de dado que vai aceitar
	public Response salvar(Produto produto) {
		try {
			produto = produtoBean.salvar(produto);
			return Response.ok(produto).build();
		} catch (Exception e) {
			return Response.serverError().entity(e.getLocalizedMessage()).build();
		}
	}	
	@DELETE
	@Produces(MediaType.APPLICATION_JSON) //é para definir o tipo de dado que vai retornar
	@Consumes(MediaType.APPLICATION_JSON)//é para definir o tipo de dado que vai aceitar
	public Response deletar(Produto produto) {
		try {
			produtoBean.deletar(produto);
			return Response.ok().build();
		} catch (Exception e) {
			return Response.serverError().entity(e.getLocalizedMessage()).build();
		}
	}
	
	@DELETE
	@Path("{id}")
	@Produces(MediaType.APPLICATION_JSON) //é para definir o tipo de dado que vai retornar
	@Consumes(MediaType.APPLICATION_JSON)//é para definir o tipo de dado que vai aceitar
	public Response deletar(@PathParam("id")Long id) {
		try {
			produtoBean.deletar(id);
			return Response.ok().build();
		} catch (Exception e) {
			return Response.serverError().entity(e.getLocalizedMessage()).build();
		}
	}
	
//	http://localhost:8080/DeliveryWeb/rest/produto/1
	@GET
	@Path("{id}")
	@Produces(MediaType.APPLICATION_JSON) //é para definir o tipo de dado que vai retornar
	@Consumes(MediaType.APPLICATION_JSON)//é para definir o tipo de dado que vai aceitar
	public Response getPorCodigo(@PathParam("id")Long id) {
		try {
			Produto produto = produtoBean.getPorCodigo(id);
			return Response.ok(produto).build();
		} catch (Exception e) {
			return Response.serverError().entity(e.getLocalizedMessage()).build();
		}
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON) //é para definir o tipo de dado que vai retornar
	@Consumes(MediaType.APPLICATION_JSON)//é para definir o tipo de dado que vai aceitar
	public Response buscarTodos() {
		try {
			List<Produto> lista = produtoBean.buscarTodos();
			return Response.ok(lista).build();
		} catch (Exception e) {
			return Response.serverError().entity(e.getLocalizedMessage()).build();
		}
	}
	
	@POST
	@Path("nome")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response buscarPorNome(String nome) {
		try {
			List<Produto> lista = produtoBean.buscarPorNome(nome);
			return Response.ok(lista).build();
		} catch (Exception e) {
			return Response.serverError().entity(e.getLocalizedMessage()).build();
		}
	}
	
	@POST
	@Path("marca")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response buscarPorMarca(String marca) {
		try {
			List<Produto> lista = produtoBean.buscarPorMarca(marca);
			return Response.ok(lista).build();
		}catch (RegraException e) {
			return Response.serverError().entity(e.getLocalizedMessage()).build();
		} catch (Exception e) {
			return Response.serverError().entity(e.getLocalizedMessage()).build();
		}
	}
	
	@POST
	@Path("categoria")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response buscarPorCategoria(String categoria) {
		try {
			List<Produto> lista = produtoBean.buscarPorCategoria(categoria);
			return Response.ok(lista).build();
		} catch (Exception e) {
			return Response.serverError().entity(e.getLocalizedMessage()).build();
		}
	}
}
