package rest;

import javax.ejb.EJB;
import javax.ws.rs.Path;

import br.unidep.ads.bean.AbstractBeanImpl;
import br.unidep.ads.bean.ClienteBean;
import br.unidep.ads.model.Cliente;

@Path("cliente")
public class ClienteWs extends AbsctractWs<Cliente>{
	
	@EJB
	private ClienteBean clienteBean;
	
	@Override
	public AbstractBeanImpl<Cliente> getBean() {
		return clienteBean;
	}
}
